#include "server.h"

int main(int argc, char const *argv[]) {


	if (argc != 4) {
		usage(argv[1]);
		exit(EXIT_FAILURE);
	}

	serverIPAddr = (char *) calloc(MINSTRSIZE, sizeof(char));

	selectDevice();
	puts(YEL"\n****************************************************");
	fprintf(stderr, "Server port number: %d\n", serverSocketNumber);
	fprintf(stderr, "server IP address: %s\n", serverIPAddr);
	puts("****************************************************"RESET);

	fprintf(stdout, GRN"Server start with these parameters: \n");
	fprintf(stdout, "%s %s %s %s", argv[0], argv[1], argv[2], argv[3]);

	fprintf(stdout, "Logs keep at %s\n", argv[3]);
	parseDataFile(argv[2]);

	fprintf(stdout, "%d provider threads created\n", providerNum);

	fprintf(stdout, "Name \t\tPerformance\tPrice\t\tDuration\n");

	for (int i = 0; i < providerNum; ++i) {
		fprintf(stderr, "%s\t\t%d\t\t%d\t\t%d\n", providers[i].providerName, providers[i].performance,
		        providers[i].price, providers[i].duration);
	}
	fprintf(stdout, ""RESET);

	providersThID = (pthread_t *) calloc(providerNum, sizeof(pthread_t));

	//	TODO: bu degisken yuzunden memory leak olabilir kontrol et!!!!
	int *providerID;
	for (int j = 0; j < providerNum; ++j) {
		providerID = (int *) calloc(1, sizeof(int));
		*providerID = j;
		int status = pthread_create(&providersThID[j], NULL, ThreadProvider, (void *) providerID);
		if (status != 0) {
			fprintf(stderr, RED"Failed to create thread: %s"RESET, strerror(errno));
			exit(EXIT_FAILURE);
		}
	}

	serverSocketNumber = (unsigned short) strtol(argv[1], NULL, 10);

	startServer();


	for (int k = 0; k < providerNum; ++k) {
		free(providers[k].providerQueue);
	}

	free(providerID);
	free(providers);
	return 0;
}

void usage(const char *programName) {
	fprintf(stderr, RED"Usage: %s <port_number> <provide_file_name> <log_file_name>"RESET, programName);
}

void parseDataFile(const char *fileName) {
	FILE *pInputFile;
	char line[BUFFSIZE], *buff;
	int i = 0;

	pInputFile = fopen(fileName, "r");

	if (pInputFile == NULL) {

	}

	fgets(line, BUFFSIZE, pInputFile);
	while (!feof(pInputFile)) {
		fgets(line, BUFFSIZE, pInputFile);
		++providerNum;
	}

	fclose(pInputFile);

	providers = (struct Provider *) calloc(providerNum, sizeof(struct Provider));

	if (providers == NULL) {
		fprintf(stderr, "failed to calloc %s", strerror(errno));
		exit(EXIT_FAILURE);
	}

	pInputFile = fopen(fileName, "r");

	fgets(line, BUFFSIZE, pInputFile);

	while (!feof(pInputFile)) {
		fgets(line, BUFFSIZE, pInputFile);

		buff = strtok(line, " ");
		strcpy(providers[i].providerName, buff);

		buff = strtok(NULL, " ");
		providers[i].performance = (int) strtol(buff, NULL, 10);

		buff = strtok(NULL, " ");
		providers[i].price = (int) strtol(buff, NULL, 10);

		buff = strtok(NULL, " ");
		providers[i].duration = (int) strtol(buff, NULL, 10);

		providers[i].countQueue = 0;
		providers[i].threadID = 0;
		providers[i].front = 0;
		providers[i].rear = -1;

		memset(&(providers[i].providerQueue[0]), 0, sizeof(providers[i].providerQueue[0]));
		memset(&(providers[i].providerQueue[1]), 0, sizeof(providers[i].providerQueue[1]));

		pthread_cond_init(&(providers[i].condVarProvider), NULL);
		pthread_mutex_init(&(providers[i].condVarLocProvider), NULL);

		++i;
		if (i == providerNum)
			break;

	}

	aliveProviderTh = i + 1;

	fclose(pInputFile);
}

int startServer() {
	pthread_t thread_id;
	memset(&serverAddress, 0, sizeof(serverAddress));
	serverAddress.sin_family = AF_INET;
	serverAddress.sin_port = htons(serverSocketNumber);


	if ((serverSock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		fprintf(stderr, RED"Failed to create socket: %s\n"RESET, strerror(errno));
		return -1;
	}

	if (bind(serverSock, (struct sockaddr *) &serverAddress, sizeof(serverAddress)) == -1) {
		fprintf(stderr, RED"Failed to bind socket to port: %s\n"RESET, strerror(errno));
		return -1;
	}

	if (listen(serverSock, 10) == -1) {
		fprintf(stderr, RED"Failed to listen socket: %s"RESET, strerror(errno));
		return -1;
	}


	while (isRunning) {
		int clientSocket = acceptClient();

		if (-1 == clientSocket) {
			break;
		}

		if (aliveProviderTh <= 0){
			fprintf(stderr, RED"NO PROVIDER IS AVAILABLE\n");
			struct Result result;
			result.error = true;
			write(clientSocket, (void *) &result, sizeof(result));
			break;
		}

		pthread_mutex_lock(&condVarLocTh);
		++aliveManagerTh;
		pthread_mutex_unlock(&condVarLocTh);

#ifdef DEBUG
		fprintf(stderr, "Client Sock: %d\n",clientSock);
#endif

		int status = pthread_create(&thread_id, NULL, ThreadManager, (void *) &clientSocket);
		if (status != 0) {
			fprintf(stderr, RED"Failed to create thread: %s"RESET, strerror(errno));
			isRunning = false;
			--aliveManagerTh;
		}

	}

//	free(client);
	close(serverSock);
	return 1;
}

int acceptClient() {
	unsigned int clientLen;

	clientLen = sizeof(struct sockaddr_in);

#ifdef DEBUG
	fprintf(stderr, "*******serverSock: %d\n",serverSock );
	fprintf(stderr, "*******clientSock: %d\n",clientSock );
#endif

	if ((clientSock = accept(serverSock, (struct sockaddr *) &clientAddress, &clientLen)) < 0) {
		perror("Failed to accept client");
		return -1;
	}

	if (clientSock < 0) {
		perror("Accept failed");
		return -1;
	}

//	clientSockArr[onlineClientNum] = clientSock;

#ifdef DEBUG
	fprintf(stderr, "serverSock: %d\n",serverSock );
	fprintf(stderr, "clientSock: %d\n",clientSock );
#endif

	return clientSock;
}

//void *ThreadConnectionHandler()

void *ThreadProvider(void *id) {
	int *providerID = (int *) id;
	bool isFinishDurationTime = false;
	struct timespec ts;
	struct timeval startTime, endTime;
	struct timeval t1, t2;
	double elapsedTime;
	struct Result result;

	clock_gettime(CLOCK_MONOTONIC, &ts);

	srand((time_t) ts.tv_nsec);

#ifdef DEBUG
	fprintf(stderr, RED"id: %d\n"RESET, *providerID);
#endif
	gettimeofday(&startTime, NULL);

	while (!isFinishDurationTime) {
		fprintf(stderr, BLU"Provider %s is waiting for a task\n"RESET, providers[*providerID].providerName);

		while (isEmpty(*providerID)) {
			pthread_cond_wait(&(providers[*providerID].condVarProvider), &(providers[*providerID].condVarLocProvider));
		}

		while (!isEmpty(*providerID)) {
			fprintf(stderr, BLU"Provider %s is processing task number %d: %d\n", providers[*providerID].providerName,
			        providers[*providerID].countQueue,
			        providers[*providerID].providerQueue[providers[*providerID].front].degree);

			gettimeofday(&t1, NULL);
			result.result = calcCosDeg(providers[*providerID].providerQueue[providers[*providerID].front].degree);


			int rand_v;
			rand_v = rand() % 15;
			while (!(5 < rand_v && rand_v < 15)) {
				rand_v = rand() % 15;
			}

			sleep(rand_v);

			gettimeofday(&t2, NULL);
			strcpy(result.providerName, providers[*providerID].providerName);
			result.cost = providers[*providerID].price;
			result.taskCompTime = (t2.tv_sec - t1.tv_sec);
			result.taskCompTime += (t2.tv_usec - t1.tv_usec) / 1000000.0;
			result.error = false;

//			pthread_mutex_lock(&condVarLocTh);

			struct Client client;
			client = peek(*providerID);


			write(client.clientSocket, (void *)&result, sizeof(result));


			fprintf(stderr, BLU"Provider %s completed task number %d: cos(%d)=%lf in %f seconds\n"RESET,
			        providers[*providerID].providerName, providers[*providerID].countQueue,
			        providers[*providerID].providerQueue[providers[*providerID].front].degree,
			        result.result,
			        result.taskCompTime);
			removeData(*providerID);
//			pthread_mutex_unlock(&condVarLocTh);
		}

		gettimeofday(&endTime, NULL);

		elapsedTime = (endTime.tv_sec - startTime.tv_sec);
		elapsedTime += (endTime.tv_usec - startTime.tv_usec) / 1000000.0;

		if (elapsedTime >= providers[*providerID].duration){
			isFinishDurationTime = true;
		}

	}

	pthread_mutex_lock(&condVarLocTh);
	--aliveProviderTh;
	pthread_mutex_unlock(&condVarLocTh);
}

double calcCosDeg(int degree) {
	double rad = 0.0, result = 0.0;
	rad = (PI / 180) * degree;

	for (int i = 0; i < DBL_DIG; ++i)
		result += pow(-1.0, i) / factorial(2 * i) * pow(rad, 2 * i);

	return result;
}

long int factorial(int n) {
	if (n <= 1) {
		return 1;
	} else {
		return n * factorial(n - 1);
	}
}

void *ThreadManager(void *clientSock) {
	int *clntSock = (int *) clientSock;
	ssize_t readBytes;
	struct Client client;
	pthread_t threadID;

	threadID = pthread_self();
	pthread_detach(threadID);

	readBytes = read(*clntSock, (void *) &client, sizeof(struct Client));
	if (readBytes == -1) {
		fprintf(stderr, RED"Failed to read from socket: %s\n"RESET, strerror(errno));
		pthread_exit(NULL);
	}

	client.clientSocket = *clntSock;

	fprintf(stdout, "==========================================\n");
	fprintf(stdout, GRN"client:");
	fprintf(stdout, "priority: %c\n", client.priority);
	fprintf(stdout, "degree: %d\n", client.degree);
	fprintf(stdout, "clientName: %s\n", client.clientName);
	fprintf(stdout, "clientSocket: %d\n"RESET, client.clientSocket);
	fprintf(stdout, "==========================================\n");

	bool isFoundBest = false;
	int bestProviderIdx = 0;
	if (client.priority == 'C') {
		for (int i = 0; i < providerNum; ++i) {
			if (providers[i].price < providers[bestProviderIdx].price && providers[i].countQueue < 2) {
				bestProviderIdx = i;
				isFoundBest = true;
			}
		}
	} else if (client.priority == 'Q') {
		for (int i = 0; i < providerNum; ++i) {
			if (providers[i].performance > providers[bestProviderIdx].performance && providers[i].countQueue < 2) {
				bestProviderIdx = i;
				isFoundBest = true;
			}
		}
	} else if (client.priority == 'T') {
		for (int i = 0; i < providerNum; ++i) {
			if (isEmpty(i)) {
				bestProviderIdx = i;
				isFoundBest = true;
				break;
			}
		}
	}

	if (!isFoundBest) {
		for (int i = 0; i < providerNum; ++i) {
			if (isEmpty(i)) {
				bestProviderIdx = i;
				isFoundBest = true;
			}
		}
	}

	if (!isFoundBest) {
		for (int i = 0; i < providerNum; ++i) {
			if (providers[i].countQueue == 1) {
				bestProviderIdx = i;
				isFoundBest = true;
			}
		}
	}

	if (!isFoundBest) {
		while (!isFoundBest) {
			for (int i = 0; i < providerNum; ++i) {
				if (providers[i].countQueue == 0 || providers[i].countQueue == 1) {
					bestProviderIdx = i;
					isFoundBest = true;
				}
			}
		}
	}

	pthread_mutex_lock(&condVarLocTh);
	insert(bestProviderIdx, client);
	--aliveManagerTh;
	pthread_mutex_unlock(&condVarLocTh);

	pthread_cond_signal(&(providers[bestProviderIdx].condVarProvider));


	return (void *) 1;
}

void selectDevice() {
	struct ifaddrs *ifap, *ifa;
	struct sockaddr_in *sa;
	char **addr;
	int connNum = 0;
	int i = 0, j = 0;

	getifaddrs(&ifap);
	for (ifa = ifap; ifa; ifa = ifa->ifa_next) {
		if (ifa->ifa_addr->sa_family == AF_INET) {
			++connNum;
		}
	}

	addr = (char **) malloc(connNum * sizeof(char *));
	for (i = 0; i < connNum; ++i) {
		addr[i] = (char *) malloc(MINSTRSIZE * sizeof(char));
	}

	i = 0;
	getifaddrs(&ifap);
	puts("****************************************************");
	for (ifa = ifap; ifa; ifa = ifa->ifa_next) {
		if (ifa->ifa_addr->sa_family == AF_INET) {
			sa = (struct sockaddr_in *) ifa->ifa_addr;
			strcpy(addr[i], inet_ntoa(sa->sin_addr));
			printf("Interface:[%d] %s          Address: %s\n", i, ifa->ifa_name, addr[i]);
			++i;
		}
	}
	puts("****************************************************");

	fprintf(stdout, "Select connection device: ");
	fscanf(stdin, "%d", &i);
	strcpy(serverIPAddr, addr[i]);
//	fprintf(stdout, "server IP address: %s-\n", serverIPAddr);
	j = 0;
	getifaddrs(&ifap);
	for (ifa = ifap; ifa; ifa = ifa->ifa_next) {
		if (ifa->ifa_addr->sa_family == AF_INET) {
			sa = (struct sockaddr_in *) ifa->ifa_addr;
			if (j == i) {
				serverAddress.sin_addr = ((struct sockaddr_in *) &ifa->ifa_addr)->sin_addr;
			}
			++j;
		}
	}


	freeifaddrs(ifap);

	for (i = 0; i < connNum; ++i)
		free(addr[i]);
	free(addr);
}

struct Client peek(int providerNum) {
	struct Client data;

	data.degree = providers[providerNum].providerQueue[providers[providerNum].front].degree;
	data.priority = providers[providerNum].providerQueue[providers[providerNum].front].priority;
	data.clientSocket = providers[providerNum].providerQueue[providers[providerNum].front].clientSocket;
	strcpy(data.clientName, providers[providerNum].providerQueue[providers[providerNum].front].clientName);

#ifdef DEBUG
	fprintf(stderr, CYN"111degree: %d\n"RESET, data.degree);
	fprintf(stderr, CYN"result: %lf\n"RESET, data.result);
	fprintf(stderr, CYN"clientSocket: %d\n"RESET, data.clientSocket);
	fprintf(stderr, CYN"clientName: %s\n"RESET, data.clientName);
	fprintf(stderr, CYN"pri: %c\n"RESET, data.priority);
	fprintf(stderr, CYN"countQueue: %d\n"RESET, providers[providerNum].countQueue);
#endif

	return data;
}

bool isEmpty(int providerNum) {
	return providers[providerNum].countQueue == 0;
}

bool isFull(int providerNum) {
	return providers[providerNum].countQueue == MAXQUEUENUM;
}

int size(int providerNum) {
	return providers[providerNum].countQueue;
}

void insert(int providerNum, struct Client newClient) {
	if (!isFull(providerNum)) {
		if (providers[providerNum].rear == MAXQUEUENUM - 1) {
			providers[providerNum].rear = -1;
		}
#ifdef DEBUG
		fprintf(stderr, MAG"provider num: %d\n"RESET, providerNum);
#endif
		++(providers[providerNum].rear);
		providers[providerNum].providerQueue[providers[providerNum].rear].degree = newClient.degree;
		providers[providerNum].providerQueue[providers[providerNum].rear].clientSocket = newClient.clientSocket;
		providers[providerNum].providerQueue[providers[providerNum].rear].priority = newClient.priority;
		strcpy(providers[providerNum].providerQueue[providers[providerNum].rear].clientName, newClient.clientName);
		++(providers[providerNum].countQueue);

#ifdef DEBUG
		fprintf(stderr, MAG"degree: %d\n"RESET,
		        providers[providerNum].providerQueue[providers[providerNum].rear].degree);
		fprintf(stderr, MAG"result: %lf\n"RESET,
		        providers[providerNum].providerQueue[providers[providerNum].rear].result);
		fprintf(stderr, MAG"clientSocket: %d\n"RESET,
		        providers[providerNum].providerQueue[providers[providerNum].rear].clientSocket);
		fprintf(stderr, MAG"clientName: %s\n"RESET,
		        providers[providerNum].providerQueue[providers[providerNum].rear].clientName);
		fprintf(stderr, MAG"pri: %c\n"RESET,
		        providers[providerNum].providerQueue[providers[providerNum].rear].priority);
		fprintf(stderr, MAG"countQueue: %d\n"RESET, providers[providerNum].countQueue);
#endif

	}
}

struct Client removeData(int providerNum) {
	struct Client data;

	strcpy(data.clientName, providers[providerNum].providerQueue[providers[providerNum].front].clientName);
	data.priority = providers[providerNum].providerQueue[providers[providerNum].front].priority;
	data.degree = providers[providerNum].providerQueue[providers[providerNum].front].degree;
	data.clientSocket = providers[providerNum].providerQueue[providers[providerNum].front].clientSocket;
	++providers[providerNum].front;
	if (providers[providerNum].front == MAXQUEUENUM) {
		providers[providerNum].front = 0;
	}
	--providers[providerNum].countQueue;
}